package Batalha_de_personagens;

import java.util.Random;

public class Personagem {
    // Atributos dos personagens (o que cada personagem tem)
    private String nome;
    private int vida;
    private int vidaMaxima;
    private int forca;
    private int defesa;
    private int nivel;
    private ClassePersonagem classe;
    private TipoMascote mascote;

    private int contadorAcoes = 0; // controla quando o pet pode ajudar

    Random random = new Random();

    public Personagem(String nome, int vidaMaxima, int forca, int defesa, int nivel, ClassePersonagem classe, TipoMascote mascote) {
        this.nome = nome;
        this.vidaMaxima = vidaMaxima;
        this.vida = vidaMaxima;
        this.forca = forca;
        this.defesa = defesa;
        this.nivel = nivel;
        this.classe = classe;
        this.mascote = mascote;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public int getVidaMaxima() {
        return vidaMaxima;
    }

    public void setVidaMaxima(int vidaMaxima) {
        this.vidaMaxima = vidaMaxima;
    }

    public int getForca() {
        return forca;
    }

    public void setForca(int forca) {
        this.forca = forca;
    }

    public int getDefesa() {
        return defesa;
    }

    public void setDefesa(int defesa) {
        this.defesa = defesa;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public ClassePersonagem getClasse() {
        return classe;
    }

    public void setClasse(ClassePersonagem classe) {
        this.classe = classe;
    }

    public TipoMascote getMascote() {
        return mascote;
    }

    public void setMascote(TipoMascote mascote) {
        this.mascote = mascote;
    }



    public void atacar(Personagem alvo) {
        contadorAcoes++; // conta ação

        System.out.println("\n>>> " + this.nome + " ataca " + alvo.getNome() + "!");

        int danoBase = random.nextInt(9,41); // 10 até 41
        int danoTotal = danoBase;

        System.out.println("Dano base: " + danoBase);

        // Mascote só ajuda depois de 2 ações
        if (contadorAcoes >= 2 && this.mascote != null && this.mascote.getHabilidade().contains("Ataque")) {
            System.out.println("O mascote " + this.mascote.name() + " ajudou no ataque causando +" + this.mascote.getValorEfeito() + " de dano!");
            danoTotal += this.mascote.getValorEfeito();
        }

        alvo.receberDano(danoTotal);
    }

    public void defender() {
        contadorAcoes++;

        System.out.println("\n>>> " + this.nome + " assumiu postura de DEFESA!");

        // Mascote só ajuda depois de 2 ações
        if (contadorAcoes >= 2 && this.mascote != null) {
            if (this.mascote.getHabilidade().equals("Cura")) {
                curar(this.mascote.getValorEfeito());
            } else if (this.mascote.getHabilidade().equals("Defesa")) {
                System.out.println("O mascote " + this.mascote.name() + " aumentou a proteção!");
            }
        }
    }

    private void receberDano(int danoAtaque) {
        int defesaTotal = this.defesa;

        if (contadorAcoes >= 2 && this.mascote != null && this.mascote.getHabilidade().equals("Defesa")) {
            defesaTotal += this.mascote.getValorEfeito();
        }

        int danoReal = danoAtaque - defesaTotal;
        if (danoReal < 0) danoReal = 0;

        this.vida -= danoReal;
        System.out.println(this.nome + " recebeu " + danoReal + " de dano!");
        if (this.vida < 0) this.vida = 0;
    }

    private void curar(int quantidade) {
        this.vida += quantidade;
        if (this.vida > this.vidaMaxima) this.vida = this.vidaMaxima;
        System.out.println("O mascote " + this.mascote.name() + " curou " + quantidade + " de vida! (" + this.vida + "/" + this.vidaMaxima + ")");
    }

    public boolean estaVivo() {
        return this.vida > 0;
    }

    public void exibirEstado() {
        System.out.println(this.nome + " [Classe: " + this.classe + " | Lvl: " + this.nivel + " | Vida: " + this.vida + "/" + this.vidaMaxima + "]");
    }

}
