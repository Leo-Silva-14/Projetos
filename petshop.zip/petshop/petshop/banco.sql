-- Criação do banco
-- CREATE DATABASE petshop;

-- Tabela de donos
CREATE TABLE dono (
    id   SERIAL PRIMARY KEY,
    nome      VARCHAR(100) NOT NULL,
    telefone  VARCHAR(20)  NOT NULL
);

-- Tabela de animais
CREATE TABLE animal (
    id       SERIAL PRIMARY KEY,
    nome     VARCHAR(100) NOT NULL,
    especie  VARCHAR(50)  NOT NULL,
    id_dono  INTEGER      NOT NULL REFERENCES dono(id)
);

-- Tabela de consultas
CREATE TABLE consulta (
    id         SERIAL PRIMARY KEY,
    id_animal  INTEGER        NOT NULL REFERENCES animal(id),
    data       DATE           NOT NULL,
    descricao  VARCHAR(255)   NOT NULL,
    valor      NUMERIC(10, 2) NOT NULL
);
