package br.unipar.poo.model;

public class Animal {

    private Integer id;
    private String nome;
    private String especie;
    private Dono dono;

    public Animal(Integer id, String nome, String especie, Dono dono) {
        this.id = id;
        this.nome = nome;
        this.especie = especie;
        this.dono = dono;
    }

    public Animal(String nome, String especie, Dono dono) {
        this.nome = nome;
        this.especie = especie;
        this.dono = dono;
    }

    public Animal() { }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public Dono getDono() {
        return dono;
    }

    public void setDono(Dono dono) {
        this.dono = dono;
    }
}
