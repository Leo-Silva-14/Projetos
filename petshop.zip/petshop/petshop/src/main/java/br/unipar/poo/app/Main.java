package br.unipar.poo.app;

import br.unipar.poo.dao.AnimalDAO;
import br.unipar.poo.dao.ConsultaDAO;
import br.unipar.poo.dao.DonoDAO;
import br.unipar.poo.dao.impl.AnimalDAOImpl;
import br.unipar.poo.dao.impl.ConsultaDAOImpl;
import br.unipar.poo.dao.impl.DonoDAOImpl;
import br.unipar.poo.model.Animal;
import br.unipar.poo.model.Consulta;
import br.unipar.poo.model.Dono;
import br.unipar.poo.service.AnimalService;
import br.unipar.poo.service.ConsultaService;
import br.unipar.poo.service.DonoService;

import java.util.List;
import java.util.Scanner;

public class Main {

// ACADÊMICOS:
// RA: 60006533 - LEONARDO ALMEIDA
// RA: 60007282 - JOSÉ AUGUSTO
// RA: 60008931 - VICTOR RUAN

    public static void main(String[] args) {

        System.out.println("Bem vindo ao sistema petshop");

        Scanner sc = new Scanner(System.in);
        int opcao;

        do {
            exibirMenu();
            opcao = sc.nextInt();

            switch (opcao) {
                case 0:
                    System.out.println("Encerrando o sistema. Até logo!");
                    return;

                case 1:
                    cadastrarDono(sc);
                    break;

                case 2:
                    cadastrarAnimal(sc);
                    break;

                case 3:
                    registrarConsulta(sc);
                    break;

                case 4:
                    listarHistorico(sc);
                    break;

                case 5:
                    listarDonos();
                    break;

                case 6:
                    listarAnimais();
                    break;

                default:
                    System.out.println("Opção inválida.");
            }

        } while (opcao != 0);
    }

    public static void exibirMenu() {
        System.out.println("\nSelecione uma opção:");
        System.out.println("1 - Cadastrar dono");
        System.out.println("2 - Cadastrar animal");
        System.out.println("3 - Registrar consulta");
        System.out.println("4 - Listar histórico de consultas por animal");
        System.out.println("5 - Listar donos");
        System.out.println("6 - Listar animais");
        System.out.println("0 - Sair");
    }

    public static void cadastrarDono(Scanner sc) {
        DonoDAO donoDAO = new DonoDAOImpl();
        DonoService donoService = new DonoService(donoDAO);

        sc.nextLine();
        System.out.println("Digite o nome do dono:");
        String nome = sc.nextLine();

        System.out.println("Digite o telefone do dono:");
        String telefone = sc.nextLine();

        try {
            Dono dono = donoService.cadastrarDono(nome, telefone);
            System.out.println("Dono cadastrado com sucesso! Código: " + dono.getId());
        } catch (RuntimeException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public static void cadastrarAnimal(Scanner sc) {
        DonoDAO donoDAO = new DonoDAOImpl();
        AnimalDAO animalDAO = new AnimalDAOImpl();
        AnimalService animalService = new AnimalService(animalDAO, donoDAO);

        listarDonos();

        sc.nextLine();
        System.out.println("Digite o código do dono:");
        int idDono = sc.nextInt();

        sc.nextLine();
        System.out.println("Digite o nome do animal:");
        String nome = sc.nextLine();

        System.out.println("Digite a espécie do animal:");
        String especie = sc.nextLine();

        try {
            Animal animal = animalService.cadastrarAnimal(nome, especie, idDono);
            System.out.println("Animal cadastrado com sucesso! Código: " + animal.getId());
        } catch (RuntimeException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public static void registrarConsulta(Scanner sc) {
        AnimalDAO animalDAO = new AnimalDAOImpl();
        ConsultaDAO consultaDAO = new ConsultaDAOImpl();
        ConsultaService consultaService = new ConsultaService(consultaDAO, animalDAO);

        listarAnimais();

        sc.nextLine();
        System.out.println("Digite o código do animal:");
        int idAnimal = sc.nextInt();

        sc.nextLine();
        System.out.println("Digite a descrição da consulta:");
        String descricao = sc.nextLine();

        System.out.println("Digite o valor da consulta:");
        double valor = sc.nextDouble();

        try {
            Consulta consulta = consultaService.registrarConsulta(idAnimal, descricao, valor);
            System.out.println("Consulta registrada com sucesso! Código: " + consulta.getId());
        } catch (RuntimeException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public static void listarHistorico(Scanner sc) {
        AnimalDAO animalDAO = new AnimalDAOImpl();
        ConsultaDAO consultaDAO = new ConsultaDAOImpl();
        ConsultaService consultaService = new ConsultaService(consultaDAO, animalDAO);

        listarAnimais();

        sc.nextLine();
        System.out.println("Digite o código do animal:");
        int idAnimal = sc.nextInt();

        try {
            List<Consulta> consultas = consultaService.listarHistoricoPorAnimal(idAnimal);

            if (consultas.isEmpty()) {
                System.out.println("Nenhuma consulta encontrada para este animal.");
                return;
            }

            System.out.println("\n--- Histórico de Consultas ---");
            for (Consulta c : consultas) {
                System.out.println("Código: " + c.getId());
                System.out.println("Animal: " + c.getAnimal().getNome() + " (" + c.getAnimal().getEspecie() + ")");
                System.out.println("Dono: " + c.getAnimal().getDono().getNome());
                System.out.println("Data: " + c.getData());
                System.out.println("Descrição: " + c.getDescricao());
                System.out.println("Valor: R$ " + String.format("%.2f", c.getValor()));
                System.out.println("------------------------------");
            }
        } catch (RuntimeException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public static void listarDonos() {
        DonoDAO donoDAO = new DonoDAOImpl();
        DonoService donoService = new DonoService(donoDAO);

        List<Dono> donos = donoService.listarTodos();

        if (donos.isEmpty()) {
            System.out.println("Nenhum dono cadastrado.");
            return;
        }

        System.out.println("\n--- Donos cadastrados ---");
        for (Dono d : donos) {
            System.out.println(d.getId() + " - " + d.getNome() + " | Tel: " + d.getTelefone());
        }
    }

    public static void listarAnimais() {
        AnimalDAO animalDAO = new AnimalDAOImpl();
        AnimalService animalService = new AnimalService(animalDAO, new DonoDAOImpl());

        List<Animal> animais = animalService.listarTodos();

        if (animais.isEmpty()) {
            System.out.println("Nenhum animal cadastrado.");
            return;
        }

        System.out.println("\n--- Animais cadastrados ---");
        for (Animal a : animais) {
            System.out.println(a.getId() + " - " + a.getNome() + " (" + a.getEspecie() + ")" +
                    " | Dono: " + a.getDono().getNome());
        }
    }
}
