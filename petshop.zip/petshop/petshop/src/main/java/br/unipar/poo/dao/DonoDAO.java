package br.unipar.poo.dao;

import br.unipar.poo.model.Dono;

public interface DonoDAO extends CrudDAO<Dono, Integer> {

}
