package br.unipar.poo.service;

import br.unipar.poo.dao.AnimalDAO;
import br.unipar.poo.dao.ConsultaDAO;
import br.unipar.poo.model.Animal;
import br.unipar.poo.model.Consulta;

import java.time.LocalDate;
import java.util.List;

// camada de regras de negócio
public class ConsultaService {

    private ConsultaDAO consultaDAO;
    private AnimalDAO animalDAO;

    public ConsultaService(ConsultaDAO consultaDAO, AnimalDAO animalDAO) {
        this.consultaDAO = consultaDAO;
        this.animalDAO = animalDAO;
    }

    public Consulta registrarConsulta(Integer idAnimal, String descricao, Double valor) {
        if (descricao == null || descricao.trim().isEmpty()) {
            throw new RuntimeException("A descrição da consulta é obrigatória.");
        }

        if (valor == null || valor <= 0) {
            throw new RuntimeException("O valor da consulta deve ser maior que zero.");
        }

        Animal animal = animalDAO.buscarPorId(idAnimal);
        if (animal == null) {
            throw new RuntimeException("Animal não encontrado. Verifique o código informado.");
        }

        Consulta consulta = new Consulta(animal, LocalDate.now(), descricao.trim(), valor);
        return consultaDAO.salvar(consulta);
    }

    public List<Consulta> listarHistoricoPorAnimal(Integer idAnimal) {
        Animal animal = animalDAO.buscarPorId(idAnimal);
        if (animal == null) {
            throw new RuntimeException("Animal não encontrado. Verifique o código informado.");
        }

        return consultaDAO.listarPorAnimal(idAnimal);
    }
}
