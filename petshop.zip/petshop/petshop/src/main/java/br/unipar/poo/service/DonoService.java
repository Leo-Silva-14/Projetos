package br.unipar.poo.service;

import br.unipar.poo.dao.DonoDAO;
import br.unipar.poo.model.Dono;

import java.util.List;

// camada de regras de negócio
public class DonoService {

    private DonoDAO donoDAO;

    public DonoService(DonoDAO donoDAO) {
        this.donoDAO = donoDAO;
    }

    public Dono cadastrarDono(String nome, String telefone) {
        if (nome == null || nome.trim().isEmpty()) {
            throw new RuntimeException("O nome do dono é obrigatório.");
        }

        if (telefone == null || telefone.trim().isEmpty()) {
            throw new RuntimeException("O telefone do dono é obrigatório.");
        }

        Dono dono = new Dono(nome.trim(), telefone.trim());
        return donoDAO.salvar(dono);
    }

    public List<Dono> listarTodos() {
        return donoDAO.listarTodos();
    }
}
