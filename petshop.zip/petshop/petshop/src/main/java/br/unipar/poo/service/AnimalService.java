package br.unipar.poo.service;

import br.unipar.poo.dao.AnimalDAO;
import br.unipar.poo.dao.DonoDAO;
import br.unipar.poo.model.Animal;
import br.unipar.poo.model.Dono;

import java.util.List;

// camada de regras de negócio
public class AnimalService {

    private AnimalDAO animalDAO;
    private DonoDAO donoDAO;

    public AnimalService(AnimalDAO animalDAO, DonoDAO donoDAO) {
        this.animalDAO = animalDAO;
        this.donoDAO = donoDAO;
    }

    public Animal cadastrarAnimal(String nome, String especie, Integer idDono) {
        if (nome == null || nome.trim().isEmpty()) {
            throw new RuntimeException("O nome do animal é obrigatório.");
        }

        if (especie == null || especie.trim().isEmpty()) {
            throw new RuntimeException("A espécie do animal é obrigatória.");
        }

        Dono dono = donoDAO.buscarPorId(idDono);
        if (dono == null) {
            throw new RuntimeException("Dono não encontrado. Cadastre o dono antes de cadastrar o animal.");
        }

        Animal animal = new Animal(nome.trim(), especie.trim(), dono);
        return animalDAO.salvar(animal);
    }

    public List<Animal> listarTodos() {
        return animalDAO.listarTodos();
    }

    public Animal buscarPorId(Integer id) {
        Animal animal = animalDAO.buscarPorId(id);
        if (animal == null) {
            throw new RuntimeException("Animal não encontrado com o id: " + id);
        }
        return animal;
    }
}
