package br.unipar.poo.dao.impl;

import br.unipar.poo.connection.ConnectionFactory;
import br.unipar.poo.dao.DonoDAO;
import br.unipar.poo.model.Dono;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DonoDAOImpl implements DonoDAO {

    @Override
    public Dono salvar(Dono entidade) {
        String sql = "INSERT INTO dono (nome, telefone) VALUES (?, ?) RETURNING id";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, entidade.getNome());
            ps.setString(2, entidade.getTelefone());

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    entidade.setId(rs.getInt("id"));
                    return entidade;
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao salvar dono.", e);
        }
        return null;
    }

    @Override
    public List<Dono> listarTodos() {
        String sql = "SELECT id, nome, telefone FROM dono ORDER BY nome";
        List<Dono> donos = new ArrayList<>();

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                donos.add(mapearDono(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar donos.", e);
        }

        return donos;
    }

    @Override
    public Dono buscarPorId(Integer id) {
        String sql = "SELECT id, nome, telefone FROM dono WHERE id = ?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapearDono(rs);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar dono.", e);
        }

        return null;
    }

    @Override
    public Dono atualizar(Dono entidade) {
        return null;
    }

    @Override
    public void deletar(Integer id) {

    }

    private Dono mapearDono(ResultSet rs) throws SQLException {
        return new Dono(
                rs.getInt("id"),
                rs.getString("nome"),
                rs.getString("telefone"));
    }
}
