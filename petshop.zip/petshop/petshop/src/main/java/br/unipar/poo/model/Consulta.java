package br.unipar.poo.model;

import java.time.LocalDate;

public class Consulta {

    private Integer id;
    private Animal animal;
    private LocalDate data;
    private String descricao;
    private Double valor;

    public Consulta(Integer id, Animal animal, LocalDate data, String descricao, Double valor) {
        this.id = id;
        this.animal = animal;
        this.data = data;
        this.descricao = descricao;
        this.valor = valor;
    }

    public Consulta(Animal animal, LocalDate data, String descricao, Double valor) {
        this.animal = animal;
        this.data = data;
        this.descricao = descricao;
        this.valor = valor;
    }

    public Consulta() { }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Animal getAnimal() {
        return animal;
    }

    public void setAnimal(Animal animal) {
        this.animal = animal;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }
}
