package br.unipar.poo.dao.impl;

import br.unipar.poo.connection.ConnectionFactory;
import br.unipar.poo.dao.AnimalDAO;
import br.unipar.poo.model.Animal;
import br.unipar.poo.model.Dono;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AnimalDAOImpl implements AnimalDAO {

    @Override
    public Animal salvar(Animal entidade) {
        String sql = "INSERT INTO animal (nome, especie, id_dono) VALUES (?, ?, ?) RETURNING id";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, entidade.getNome());
            ps.setString(2, entidade.getEspecie());
            ps.setInt(3, entidade.getDono().getId());

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    entidade.setId(rs.getInt("id"));
                    return entidade;
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao salvar animal.", e);
        }
        return null;
    }

    @Override
    public List<Animal> listarTodos() {
        String sql = "SELECT a.id, a.nome, a.especie, d.id AS id_dono, d.nome AS nome_dono, d.telefone " +
                     "FROM animal a JOIN dono d ON a.id_dono = d.id ORDER BY a.nome";
        List<Animal> animais = new ArrayList<>();

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                animais.add(mapearAnimal(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar animais.", e);
        }

        return animais;
    }

    @Override
    public Animal buscarPorId(Integer id) {
        String sql = "SELECT a.id, a.nome, a.especie, d.id AS id_dono, d.nome AS nome_dono, d.telefone " +
                     "FROM animal a JOIN dono d ON a.id_dono = d.id WHERE a.id = ?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapearAnimal(rs);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar animal.", e);
        }

        return null;
    }

    @Override
    public Animal atualizar(Animal entidade) {
        return null;
    }

    @Override
    public void deletar(Integer id) {

    }

    private Animal mapearAnimal(ResultSet rs) throws SQLException {
        Dono dono = new Dono(
                rs.getInt("id_dono"),
                rs.getString("nome_dono"),
                rs.getString("telefone"));

        return new Animal(
                rs.getInt("id"),
                rs.getString("nome"),
                rs.getString("especie"),
                dono);
    }
}
