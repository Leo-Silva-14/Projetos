package br.unipar.poo.dao;

import br.unipar.poo.model.Consulta;

import java.util.List;

public interface ConsultaDAO extends CrudDAO<Consulta, Integer> {

    List<Consulta> listarPorAnimal(Integer idAnimal);

}
