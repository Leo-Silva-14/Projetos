package br.unipar.poo.dao.impl;

import br.unipar.poo.connection.ConnectionFactory;
import br.unipar.poo.dao.ConsultaDAO;
import br.unipar.poo.model.Animal;
import br.unipar.poo.model.Consulta;
import br.unipar.poo.model.Dono;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ConsultaDAOImpl implements ConsultaDAO {

    @Override
    public Consulta salvar(Consulta entidade) {
        String sql = "INSERT INTO consulta (id_animal, data, descricao, valor) VALUES (?, ?, ?, ?) RETURNING id";

        try (Connection conn = ConnectionFactory.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, entidade.getAnimal().getId());
                ps.setDate(2, Date.valueOf(entidade.getData()));
                ps.setString(3, entidade.getDescricao());
                ps.setDouble(4, entidade.getValor());

                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        entidade.setId(rs.getInt("id"));
                    }
                }

                conn.commit();
                return entidade;

            } catch (SQLException e) {
                conn.rollback();
                throw new RuntimeException("Erro ao salvar consulta. Operação revertida.", e);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro de conexão ao registrar consulta.", e);
        }
    }

    @Override
    public List<Consulta> listarTodos() {
        return listarPorAnimal(null);
    }

    @Override
    public List<Consulta> listarPorAnimal(Integer idAnimal) {
        String sql = "SELECT c.id, c.data, c.descricao, c.valor, " +
                     "a.id AS id_animal, a.nome AS nome_animal, a.especie, " +
                     "d.id AS id_dono, d.nome AS nome_dono, d.telefone " +
                     "FROM consulta c " +
                     "JOIN animal a ON c.id_animal = a.id " +
                     "JOIN dono d ON a.id_dono = d.id ";

        if (idAnimal != null) {
            sql += "WHERE c.id_animal = ? ";
        }

        sql += "ORDER BY c.data DESC";

        List<Consulta> consultas = new ArrayList<>();

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            if (idAnimal != null) {
                ps.setInt(1, idAnimal);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    consultas.add(mapearConsulta(rs));
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar consultas.", e);
        }

        return consultas;
    }

    @Override
    public Consulta buscarPorId(Integer id) {
        return null;
    }

    @Override
    public Consulta atualizar(Consulta entidade) {
        return null;
    }

    @Override
    public void deletar(Integer id) {

    }

    private Consulta mapearConsulta(ResultSet rs) throws SQLException {
        Dono dono = new Dono(
                rs.getInt("id_dono"),
                rs.getString("nome_dono"),
                rs.getString("telefone"));

        Animal animal = new Animal(
                rs.getInt("id_animal"),
                rs.getString("nome_animal"),
                rs.getString("especie"),
                dono);

        return new Consulta(
                rs.getInt("id"),
                animal,
                rs.getDate("data").toLocalDate(),
                rs.getString("descricao"),
                rs.getDouble("valor"));
    }
}
