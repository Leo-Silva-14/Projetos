package br.unipar.poo.dao;

import br.unipar.poo.model.Animal;

public interface AnimalDAO extends CrudDAO<Animal, Integer> {

}
